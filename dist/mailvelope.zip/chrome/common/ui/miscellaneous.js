/**
 * Mailvelope - secure email with OpenPGP encryption for Webmail
 * Copyright (C) 2012  Thomas Oberndörfer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License version 3
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

(function() {

    var publicKeyRegex = /-----BEGIN PGP PUBLIC KEY BLOCK-----[\s\S]+?-----END PGP PUBLIC KEY BLOCK-----/g;
    var privateKeyRegex = /-----BEGIN PGP PRIVATE KEY BLOCK-----[\s\S]+?-----END PGP PRIVATE KEY BLOCK-----/g;

    function init() {
        $('#misKeySubmit').click(saveData);

        $("#credentialCB").click(changeCredentialsState);

        loadUpdatePath();
        clearUpdateMessagePanel();
    }

    function changeCredentialsState(){
        var checked_status = document.getElementById('credentialCB').checked;
        if (checked_status == true) {
            $("#usernameId").removeAttr("disabled");
            $("#passwordId").removeAttr("disabled");
        } else {
            $("#usernameId").attr("disabled", "disabled");
            $("#passwordId").attr("disabled", "disabled");
            document.getElementById('usernameId').setAttribute('value', '');
            document.getElementById('passwordId').setAttribute('value', '');
        }
    }

    function addCredentialsToURL(url){
        var username = document.getElementById('usernameId').value;
        var password = document.getElementById('passwordId').value;
        var credentialURL = url.replace("://", "://"+username+":"+password+"@");
        return credentialURL;
    }

    function updateKeys(){
        // get the file from stored url
        var request = new XMLHttpRequest();
        if (request == null){
            console.log("FAILURE: request == null")
        }else{
            var url = document.getElementById('misKeyFilepath').value;
            if(document.getElementById('credentialCB').checked){
                url = addCredentialsToURL(url);
            }
            console.log("URL: " + url);
            request.onreadystatechange = function()
            {
                if(request.readyState == 4)
                {
                    importKey(request.responseText);
                }
            }
            request.open("GET", url, true);
            request.send(null);
        }
    }

    function updateKeyRingUI(){
        // panelid = keyRingPanelId
        // code = <input type="button" value="Update" class="btn btn-primary" style="float:right"/>
        // panel append child to id: displayKeys
        var updateButtonFlag = document.getElementById('updateCB').checked;
        var updateButton = document.getElementById('updateButtonId');
        var updateMessagePanel = document.getElementById('updateMessagePanelId');
        if(!updateButton && updateButtonFlag){
            document.getElementById('displayKeys').appendChild(createUpdateMessagePanel());
            document.getElementById('keyRingPanelId').appendChild(createUpdateButton());
            $('#updateButtonId').click(updateKeys);
        } else if (updateButton && !updateButtonFlag){
            document.getElementById('keyRingPanelId').removeChild(updateButton);
            document.getElementById('displayKeys').removeChild(updateMessagePanel);
        }
    }

    function createUpdateButton(){
        var updateButton = document.createElement('input');
        updateButton.setAttribute('id', 'updateButtonId');
        updateButton.setAttribute('type', 'button');
        updateButton.setAttribute('value', 'Update');
        updateButton.setAttribute('class', 'btn btn-primary');
        updateButton.setAttribute('style', 'float:right');
        return updateButton;
    }

    function createUpdateMessagePanel(){
        var updateMessagePanel = document.createElement('div');
        updateMessagePanel.setAttribute('class', 'control-group');
        updateMessagePanel.setAttribute('id', 'updateMessagePanelId');
        return updateMessagePanel;
    }

    function createTestLink(url){
        var testLink = document.createElement('a');
        testLink.setAttribute('id', 'testLinkId');
        testLink.setAttribute('href', url);
        testLink.innerHTML = "Test connection";
        return testLink;
    }

    function loadUpdatePath() {
        keyRing.viewModel('getUpdatePath', function(jsonINObject) {
            var jsonObject = JSON.parse(jsonINObject);

            var url = jsonObject[0]['url'];
            var credentials = jsonObject[1]['credentials'];
            var username = jsonObject[2]['username'];
            var password = jsonObject[3]['password'];
            var updateButton = jsonObject[4]['updateButton'];

            // Update testLink
            var testLink = document.getElementById('testLinkId');
            if(testLink && !url){
                document.getElementById('filePathPanelId').removeChild(testLink);
            } else if (!testLink && url){
                document.getElementById('filePathPanelId').appendChild(createTestLink(url));
            } else if (testLink && url){
                testLink.setAttribute('href', url);
            }

            document.getElementById('misKeyFilepath').setAttribute('value', url);

            if (credentials){
                document.getElementById('credentialCB').checked = true;
                document.getElementById('usernameId').setAttribute("value", username);
                document.getElementById('passwordId').setAttribute("value", password);
            } else {
                document.getElementById('credentialCB').checked = false;
                document.getElementById('usernameId').setAttribute("value", "");
                document.getElementById('passwordId').setAttribute("value", "");
            }

            changeCredentialsState();

            if (updateButton){
                document.getElementById('updateCB').checked = true;
            } else {
                document.getElementById('updateCB').checked = false;
            }

            // Update the key ring update button
            updateKeyRingUI();
            clearUpdateMessagePanel();
        });
    }

    function clearUpdateMessagePanel(){
        var updateMessagePanel = document.getElementById('updateMessagePanelId');
        if (updateMessagePanel){
            while(updateMessagePanel.firstChild) {
                updateMessagePanel.removeChild(updateMessagePanel.firstChild);
            }
        }
    }

    function importKey(text) {
        clearUpdateMessagePanel();

        var keyText = text;

        // find all public and private keys in the textbox
        var publicKeys = keyText.match(publicKeyRegex);
        var privateKeys = keyText.match(privateKeyRegex);
        var npublic = publicKeys===null ? 0 : publicKeys.length;
        var nprivate = privateKeys===null ? 0 : privateKeys.length;
        var ntotal = npublic+nprivate, nsucceeded = 0, nfailed = 0;

        // each one is imported asynchronously.
        // produce a list of success/error message boxes
        // once they're all done, call importDone() to refresh the ui
        var importKey = function(key, keyType){
            keyRing.viewModel('importKey', [key, keyType.toLowerCase()], function(result, error){
                if (!error){
                    $('#updateMessagePanelId').showAlert('Success', keyType + ' key ' + result[0].keyid + ' of user ' + result[0].userid + ' imported into key ring', 'success', true);
                    console.log("SUCCESS DUPLICAT: ");
                    nsucceeded++;
                }
                else if (error.type === 'info'){
                    $('#updateMessagePanelId').showAlert('Import Info', error.type === 'info' ? error.message : 'Duplicate was not imported', 'info', true);
                    console.log("INFO DUPLICAT: ");
                    nsucceeded++;
                }
                else if (error.type === 'error') {
                    $('#updateMessagePanelId').showAlert('Import Error', error.type === 'error' ? error.message : 'Not a valid key text', 'error', true);
                    console.log("ERROR: ");
                    nfailed++;
                }
                if(nsucceeded + nfailed == ntotal){
                    // finished importing!
                    importDone(nsucceeded > 0);
                }
            });
        }
        for(var i = 0; i < npublic; i++){
            importKey(publicKeys[i], 'Public');
        }
        for(var i = 0; i < nprivate; i++){
            importKey(privateKeys[i], 'Private');
        }

        // no keys found...
        if (ntotal == 0) {
            //$('#misAlert').showAlert('Import Error', 'Not a valid key text', 'error');
        }
    }

    function buildJSON (url, credentials, username, password, updateButton){

        if (!url) {
            url = document.getElementById('currentPathId').value;
        }
        return [{ url: url }, { credentials: credentials }, { username: username}, { password: password }, { updateButton: updateButton}];
    }


    function saveData()
    {
        var url = document.getElementById('misKeyFilepath').value;
        var username = document.getElementById('usernameId').value;
        var password = document.getElementById('passwordId').value;
        var credentials = document.getElementById('credentialCB').checked;
        var updateButton = document.getElementById('updateCB').checked;

        if(!credentials){
            username = "";
            password = "";
        }

        var jsonObject = buildJSON(url, credentials, username, password, updateButton);
        var jsonString = JSON.stringify(jsonObject);
        keyRing.sendMessage({
            event: "set-update-url",
            data: jsonString
        });
        $('#misAlert').showAlert('Save Info', 'Successfully saved', 'info');
        loadUpdatePath();
    }

    function importDone(success) {
        console.log('importDone', success);
        if (success) {
            // at least one key was imported
            $('#newKey, #impKeySubmit, #impKeyClear, #impKeyFilepath').prop('disabled', true);
            $('#impKeyAnother').removeClass('hide');
            // refresh grid
            keyRing.viewModel('getKeys', function(result) {
                $("#mainKeyGrid").data("kendoGrid").dataSource.data(keyRing.mapDates(result));
            });
        }
    }

    $(document).ready(init);

}()); 
 
