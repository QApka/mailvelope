/**
 * Mailvelope - secure email with OpenPGP encryption for Webmail
 * Copyright (C) 2012  Thomas Oberndörfer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License version 3
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

(function() {

    // define enum
    var HIDDEN_ELEMENT = {};

    function defineEnum(){
        HIDDEN_ELEMENT = {
            URL : {value: document.getElementById('hiddenUrl'), type: "text"},
            CREDENTIAL_CB: {value: document.getElementById('hiddenCredentialCB'), type: "checkbox"},
            USERNAME: {value: document.getElementById('hiddenUsername'), type: "text"},
            PASSWORD: {value: document.getElementById('hiddenPassword'), type: "text"},
            UPDATE_BUTTON_CB : {value: document.getElementById('hiddenUpdateCB'), type: "checkbox"}
        };
    }


    var publicKeyRegex = /-----BEGIN PGP PUBLIC KEY BLOCK-----[\s\S]+?-----END PGP PUBLIC KEY BLOCK-----/g;
    var privateKeyRegex = /-----BEGIN PGP PRIVATE KEY BLOCK-----[\s\S]+?-----END PGP PRIVATE KEY BLOCK-----/g;

    function init() {
        defineEnum();
        $('#misKeySubmit').click(saveData);

        $("#credentialCB").click(changeCredentialsState);

        loadUpdatePath();
        clearUpdateMessagePanel();
    }

    function getPropertyValue(hiddenElementEnum){

        if(hiddenElementEnum.type == "checkbox"){
            return hiddenElementEnum.value.checked;
        }
        return hiddenElementEnum.value.value;
    }

    function setPropertyValue(hiddenElementEnum, value){

        if(hiddenElementEnum.type == "checkbox"){
            hiddenElementEnum.value.checked = value;
        }
        hiddenElementEnum.value.value = value;
    }


    function changeCredentialsState(){
        var checked_status = document.getElementById('credentialCB').checked;
        if (checked_status == true) {
            $("#usernameId").removeAttr("disabled");
            $("#passwordId").removeAttr("disabled");
        } else {
            document.getElementById('usernameId').value = '';
            document.getElementById('passwordId').value = '';
            $("#usernameId").attr("disabled", "disabled");
            $("#passwordId").attr("disabled", "disabled");
        }
    }

    function addCredentialsToURL(url){
        var username = document.getElementById('usernameId').value;
        var password = document.getElementById('passwordId').value;
        var credentialURL = url.replace("://", "://"+username+":"+password+"@");
        return credentialURL;
    }

    function updateKeys(){
        // get the file from stored url
        var request = new XMLHttpRequest();
        if (request == null){
            console.log("FAILURE: request == null")
        }else{
            var url = getPropertyValue(HIDDEN_ELEMENT.URL);
            if(getPropertyValue(HIDDEN_ELEMENT.CREDENTIAL_CB)){
                url = addCredentialsToURL(url);
            }
            console.log("URL: " + url);
            request.onreadystatechange = function()
            {
                if(request.readyState == 4)
                {
                    importKey(request.responseText);
                }
            }
            request.open("GET", url, true);
            request.send(null);
        }
    }

    function updateKeyRingUI(){
        // panelid = keyRingPanelId
        // code = <input type="button" value="Update" class="btn btn-primary" style="float:right"/>
        // panel append child to id: displayKeys
        var updateButtonFlag = document.getElementById('updateCB').checked;
        var updateButton = document.getElementById('updateButtonId');
        var updateMessagePanel = document.getElementById('updateMessagePanelId');
        if(!updateButton && updateButtonFlag){
            document.getElementById('displayKeys').appendChild(createUpdateMessagePanel());
            document.getElementById('keyRingPanelId').appendChild(createUpdateButton());
            $('#updateButtonId').click(updateKeys);
        } else if (updateButton && !updateButtonFlag){
            document.getElementById('keyRingPanelId').removeChild(updateButton);
            document.getElementById('displayKeys').removeChild(updateMessagePanel);
        }
    }

    function createUpdateButton(){
        var updateButton = document.createElement('input');
        updateButton.setAttribute('id', 'updateButtonId');
        updateButton.setAttribute('type', 'button');
        updateButton.setAttribute('value', 'Update');
        updateButton.setAttribute('class', 'btn btn-primary');
        updateButton.setAttribute('style', 'float:right');
        return updateButton;
    }

    function createUpdateMessagePanel(){
        var updateMessagePanel = document.createElement('div');
        updateMessagePanel.setAttribute('class', 'control-group');
        updateMessagePanel.setAttribute('id', 'updateMessagePanelId');
        return updateMessagePanel;
    }

    function createTestLink(url){
        var testLink = document.createElement('a');
        testLink.setAttribute('id', 'testLinkId');
        testLink.setAttribute('href', url);
        testLink.innerHTML = "Test connection";
        return testLink;
    }

    function loadUpdatePath() {
        keyRing.viewModel('getUpdatePath', function(jsonINObject) {
            var jsonObject = JSON.parse(jsonINObject);

            var url = jsonObject[0]['url'];
            var credentials = jsonObject[1]['credentials'];
            var username = jsonObject[2]['username'];
            var password = jsonObject[3]['password'];
            var updateButton = jsonObject[4]['updateButton'];


            // Update testLink
            var testLink = document.getElementById('testLinkId');
            if(testLink && !url){
                document.getElementById('filePathPanelId').removeChild(testLink);
            } else if (!testLink && url){
                document.getElementById('filePathPanelId').appendChild(createTestLink(url));
            } else if (testLink && url){
                testLink.setAttribute('href', url);
            }

            document.getElementById('misKeyFilepath').setAttribute('value', url);

            if (credentials){
                document.getElementById('credentialCB').checked = true;
                document.getElementById('usernameId').setAttribute("value", username);
                document.getElementById('passwordId').setAttribute("value", password);
            } else {
                document.getElementById('credentialCB').checked = false;
                document.getElementById('usernameId').setAttribute("value", "");
                document.getElementById('passwordId').setAttribute("value", "");
            }

            changeCredentialsState();

            if (updateButton){
                document.getElementById('updateCB').checked = true;
            } else {
                document.getElementById('updateCB').checked = false;
            }

            // set hidden inputs
            setPropertyValue(HIDDEN_ELEMENT.URL, url);
            setPropertyValue(HIDDEN_ELEMENT.CREDENTIAL_CB, credentials);
            setPropertyValue(HIDDEN_ELEMENT.USERNAME, username);
            setPropertyValue(HIDDEN_ELEMENT.PASSWORD, password);
            setPropertyValue(HIDDEN_ELEMENT.UPDATE_BUTTON_CB, updateButton);

            // Update the key ring update button
            updateKeyRingUI();
            clearUpdateMessagePanel();
        });
    }

    function clearUpdateMessagePanel(){
        var updateMessagePanel = document.getElementById('updateMessagePanelId');
        if (updateMessagePanel){
            while(updateMessagePanel.firstChild) {
                updateMessagePanel.removeChild(updateMessagePanel.firstChild);
            }
        }
    }

    function importKey(text) {
        clearUpdateMessagePanel();

        var keyText = text;

        // find all public and private keys in the textbox
        var publicKeys = keyText.match(publicKeyRegex);
        var privateKeys = keyText.match(privateKeyRegex);
        var npublic = publicKeys===null ? 0 : publicKeys.length;
        var nprivate = privateKeys===null ? 0 : privateKeys.length;
        var ntotal = npublic+nprivate, nsucceeded = 0, nfailed = 0;

        // each one is imported asynchronously.
        // produce a list of success/error message boxes
        // once they're all done, call importDone() to refresh the ui
        var importKey = function(key, keyType){

            keyRing.viewModel('importKey', [key, keyType.toLowerCase()], function(result, error){
                if (!error && result[0].type != 'info'){
                    $('#updateMessagePanelId').showAlert('Success', keyType + ' key ' + result[0].keyid + ' of user ' + result[0].userid + ' imported into key ring', 'success', true);
                    console.log("SUCCESS DUPLICAT: ");
                    nsucceeded++;
                }
                else if (!error && result[0].type == 'info'){
                    $('#updateMessagePanelId').showAlert('Import Info', keyType + ' key ' + result[0].keyid + ' of user ' + result[0].userid + ' is already in key ring', 'info', true);
                    console.log("INFO DUPLICAT: ");
                    nsucceeded++;
                }
                else if (error.type === 'error') {
                    $('#updateMessagePanelId').showAlert('Import Error', 'Not a valid key text', 'error', true);
                    console.log("ERROR: ");
                    nfailed++;
                }
                if(nsucceeded + nfailed == ntotal){
                    // finished importing!
                    importDone(nsucceeded > 0);
                }
            });
        }
        for(var i = 0; i < npublic; i++){
            importKey(publicKeys[i], 'Public');
        }
        for(var i = 0; i < nprivate; i++){
            importKey(privateKeys[i], 'Private');
        }

        // no keys found...
        if (ntotal == 0) {
            //$('#misAlert').showAlert('Import Error', 'Not a valid key text', 'error');
        }
    }

    function buildJSON (url, credentials, username, password, updateButton){

        if (!url) {
            url = getPropertyValue(HIDDEN_ELEMENT.URL);
        }
        return [{ url: url }, { credentials: credentials }, { username: username}, { password: password }, { updateButton: updateButton}];
    }


    function saveData()
    {
        // Read data from shown input fields to save
        var url = document.getElementById('misKeyFilepath').value;
        var username = document.getElementById('usernameId').value;
        var password = document.getElementById('passwordId').value;
        var credentials = document.getElementById('credentialCB').checked;
        var updateButton = document.getElementById('updateCB').checked;

        // todo: encrypt password

        // if credentials is not checked, remove username and password
        if(!credentials){
            username = "";
            password = "";
        }

        var jsonObject = buildJSON(url, credentials, username, password, updateButton);
        var jsonString = JSON.stringify(jsonObject);
        keyRing.sendMessage({
            event: "set-update-url",
            data: jsonString
        });
        $('#misAlert').showAlert('Save Info', 'Successfully saved', 'success');
        loadUpdatePath();
    }


    function importDone(success) {
        console.log('importDone', success);
        if (success) {
            // at least one key was imported
            // refresh grid
            keyRing.viewModel('getKeys', function(result) {
                //panelid: updateMessagePanelId
                $("#mainKeyGrid").data("kendoGrid").dataSource.data(keyRing.mapDates(result));
            });
        }
    }

    //todo encrypt function
    function encrypt(){

    }

    //todo decrypt function
    function decrypt(){

    }

    $(document).ready(init);

}()); 
 
